library(testthat)
library(rpivotTable)

test_check("rpivotTable")
# skip_on_cran("rpivotTable")
