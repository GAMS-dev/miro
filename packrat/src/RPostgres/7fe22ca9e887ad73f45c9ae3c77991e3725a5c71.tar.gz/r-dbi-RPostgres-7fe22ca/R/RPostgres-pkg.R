#' @importFrom hms hms
#' @importFrom bit64 integer64
"_PACKAGE"
