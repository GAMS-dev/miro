#ifndef __RPOSTGRES_MY_UTILS__
#define __RPOSTGRES_MY_UTILS__

int days_from_civil(int y, int m, int d);
time_t tm_to_time_t(const tm& tm_);

#endif
